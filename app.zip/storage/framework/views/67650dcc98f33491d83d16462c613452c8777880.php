

<?php $__env->startSection('title', 'Dashboard'); ?>

<?php $__env->startSection('content_header'); ?>
    <h1>Dashboard</h1>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <form action="<?php echo e(URL::to('admin/asuransi/' . $asuransi->id )); ?>" method="post">
        <?php echo csrf_field(); ?>
        <?php echo method_field("put"); ?>

        <label> Jenis Asuransi </label>
        <input type="text" name="nama" class="form-control" value="<?php echo e($asuransi->nama); ?>">

        <label> Bobot / Nilai </label>
        <input type="text" name="nilai" class="form-control" value="<?php echo e($asuransi->nilai); ?>">

        <input type="submit" value="simpan" name="simpan" class="btn btn-success">

    </form>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
    <link rel="stylesheet" href="/css/admin_custom.css">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    <script> console.log('Hi!'); </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\smartkid\resources\views/admin/asuransi/edit.blade.php ENDPATH**/ ?>