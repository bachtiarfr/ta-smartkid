

<?php $__env->startSection('title', 'Dashboard'); ?>

<?php $__env->startSection('content_header'); ?>
    <h1>Dashboard</h1>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-md-8">
            <form action="<?php echo e(URL::to('admin/orangtua')); ?>" method="post">
                <?php echo csrf_field(); ?>
                <label> Nama Orang Tua</label>
                <input type="text" name="nama" class="form-control">

                <label> Status </label>
                <select name="status" class="form-control">
                    <option selected value="ayah"> Ayah </option>
                    <option value="ibu"> Ibu </option>
                    <option value="wali"> Wali Murid </option>
                </select>

                <label> Nomer Induk Kependudukan </label>
                <input type="text" name="nik" class="form-control">

                <label> Pendidikan Terakhir </label>
                <select name="pendidikan" class="form-control">
                    <option value="sd"> Sekolah Dasar </option>
                    <option value="smp"> Sekolah Menengah Pertama </option>
                    <option selected value="sma/k"> Sekolah Menengah Atas/Kejuruan </option>
                    <option value="s1"> Sarjanah Strata 1 </option>
                    <option value="s2"> Sarjanah Strata 2 </option>
                    <option value="s3"> Sarjanah Strata 3 </option>
                </select>

                <label> Pekerjaan </label>
                <input type="text" name="pekerjaan" class="form-control">

                <input type="submit" value="simpan" name="simpan" class="btn btn-success">
            </form>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
    <link rel="stylesheet" href="/css/admin_custom.css">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    <script> console.log('Hi!'); </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\smartkid\resources\views/admin/ortu/create.blade.php ENDPATH**/ ?>