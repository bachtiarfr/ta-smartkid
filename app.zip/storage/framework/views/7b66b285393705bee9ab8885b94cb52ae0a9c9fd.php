

<?php $__env->startSection('title', 'Dashboard'); ?>

<?php $__env->startSection('content_header'); ?>
<h1>Dashboard</h1>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>


    <div class="row">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header alert-success">
                   Profil Siswa
                </div>
                <div class="card-body">
                   <div class="row">
                    <div class="col-md-3">
                        <Label> Nama Siswa </Label>
                        <select id="siswa_id" name="siswa_id" class="form-control">
                            <?php $__currentLoopData = $siswa; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sw): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($sw->id); ?>"> <?php echo e($sw->name); ?> </option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                    <div class="col-md-3">
                        <Label> Penghasilan Orangtua </Label>
                        <select id="penghasilan_id" name="penghasilan_id" class="form-control">
                            <?php $__currentLoopData = $penghasilan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $hsl): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option data-id="<?php echo e($hsl->bobot); ?>" value="<?php echo e($hsl->id); ?>"> <?php echo e($hsl->penghasilan); ?> </option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                    <div class="col-md-3">
                        <Label> Jumlah Tanggungan Orangtua </Label>
                        <select id="tanggungan_id" name="tanggungan_id" class="form-control">
                            <?php $__currentLoopData = $tanggungan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tgn): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option data-id="<?php echo e($tgn->nilai); ?>" value="<?php echo e($tgn->id); ?>"> <?php echo e($tgn->jumlah); ?> </option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                    <div class="col-md-3">
                        <Label> Jenis Asuransi Kesehatan </Label>
                        <select id="asuransi_id" name="asuransi_id" class="form-control">
                            <?php $__currentLoopData = $asuransi; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $asr): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option data-id="<?php echo e($asr->nilai); ?>" value="<?php echo e($asr->id); ?>"> <?php echo e($asr->nama); ?> </option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>    
                   </div> 
                </div>
            </div>
        </div>
    </div>

    <div class="row">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header alert-success">
                  Asset
                </div>
                <div class="card-body" id="dvasset">
                  <div id="row_rumah" class="row">
                    <?php $__currentLoopData = $rumah; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rmh): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="col-md-3">
                            <label><?php echo e($rmh->keterangan); ?></label>
                            <select name="rumah_id" id="rumah_id" class="form-control">
                                <?php $__currentLoopData = $rmh->rumahdetail; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rdet): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($rmh->id); ?>" data-id="<?php echo e($rdet->value); ?>"> <?php echo e($rdet->key); ?> </option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </div>
                  <div id="row_asset" class="row">
                    <?php $__currentLoopData = $assets; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ast): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="col-md-3">
                            <label><?php echo e($ast->nama); ?></label>
                            <select name="assets_id" id="assets_id" class="form-control">
                                <?php $__currentLoopData = $ast->assetsdetail; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $asdet): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($ast->id); ?>" data-id="<?php echo e($asdet->value); ?>"> <?php echo e($asdet->key); ?> </option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </div>
                </div>
            </div>
        </div>
    </div>
    
    <div class="row">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header alert-success">
                  Hewan Ternak
                </div>
                <div class="card-body" id="dvternak">
                  <div id="row_ternak" class="row">
                    <?php $__currentLoopData = $ternak; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $trk): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="col-md-3">
                            <label><?php echo e($trk->nama); ?></label>
                            <select name="ternak_id" id="ternak_id" class="form-control">
                                <?php $__currentLoopData = $trk->ternakdetail; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tdet): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($trk->id); ?>" data-id="<?php echo e($tdet->value); ?>"> <?php echo e($tdet->key); ?> </option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </div>
                </div>
              </div>
        </div>
    </div>

    <input type="submit" value="simpan" class="btn btn-primary" name="simpan" id="btnsimpan">

<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
  <script>
      $(function () {

        $.ajaxSetup({
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            }
        });

        $('#btnsimpan').click(function (e) { 
            e.preventDefault();

            //profil siswa
            let siswa_id = $('#siswa_id').val();
            let penghasilan_id = $('#penghasilan_id').val();
            let tanggungan_id = $('#tanggungan_id').val();
            let asuransi_id = $('#asuransi_id').val();

            //membaca selectedOptions penghasilan, tanggungan, asuransi untuk c1,c5,c6
            const gaji_bobot = document.querySelector('#penghasilan_id');
            const tanggungan_bobot = document.querySelector('#tanggungan_id');
            const asuransi_bobot = document.querySelector('#asuransi_id');

            // variable rumah
            let rumah_val = $('#rumah_id option:selected').val();
            let rumah_data_id = $('#rumah_id option:selected').data('id');
            //variable asset
            let assets_val = $('#assets_id option:selected').val();
            let assets_data_id = $('#assets_id option:selected').data('id');

            //variable
            let c1 = gaji_bobot.selectedOptions[0].getAttribute("data-id");
            let c2 = 0;
            let jml_c2 = 0;
            let c5 = tanggungan_bobot.selectedOptions[0].getAttribute("data-id");
            let c6 = asuransi_bobot.selectedOptions[0].getAttribute("data-id");

            // 

            let count_row_rumah = $('#dvasset > #row_rumah').find('option:selected').each(function () {
                // console.log(this.value);

                console.log( $(this).data("id") );
                c2 += $(this).data("id") ;
            });

            c2 = parseFloat( c2 / count_row_rumah.length ).toFixed(2) ;

            console.log( c2 );

            //get data asset - row_asset

            let c3 = 0;
            let jml_c3 = 0;
           
            let count_row_asset = $('#dvasset > #row_asset').find('option:selected').each(function () {
                // console.log(this.value);

                console.log( $(this).data("id") );
                c3 += $(this).data("id");
            });

            c3 = parseFloat( c3 / count_row_asset.length ).toFixed(2) ;

            console.log( c3 );

            //get data ternak - row_ternak 

            let c4 = 0;
            let jml_c4 = 0;
            
            let count_row_ternak = $('#dvternak > #row_ternak').find('option:selected').each(function () {
                // console.log(this.value);

                console.log( $(this).data("id") );
                c4 += $(this).data("id");
            });

            c4 = parseFloat( c4 / count_row_ternak.length ).toFixed(2) ;

            console.log( c4 );

            // let rumah_data = $(this).data("id");

            
            //simpan ke tabel penilaian
            $.ajax({
                type: "POST",
                url: "/admin/penilaian",
                data: {
                    siswa_id : siswa_id,
                    penghasilan_id : penghasilan_id,
                    tanggungan_id : tanggungan_id,
                    asuransi_id : asuransi_id,
                    c1 : c1,
                    c2 : c2,
                    c3 : c3,
                    c4 : c4,
                    c5 : c5,
                    c6 : c6
                },
                success: function (response) {
                    console.log( response );
                }
            });
            
        });
      });
  </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\smartkid\resources\views/admin/penilaian/create.blade.php ENDPATH**/ ?>