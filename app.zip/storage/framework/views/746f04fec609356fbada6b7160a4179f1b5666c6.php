

<?php $__env->startSection('title', 'Data Kriteria Tanggungan Anak'); ?>

<?php $__env->startSection('content_header'); ?>
    <h1>Data Kriteria Tanggungan Anak</h1>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <?php if($message = Session::get('success')): ?>
        <div class="alert alert-success">
            <p><?php echo e($message); ?></p>
        </div>
    <?php endif; ?>

    <table class="table table-striped table-hover table-bordered">
        <tr>
            <th> No </th>
            <th> Tanggungan Anak Sekolah </th>
            <th> Bobot / Nilai </th>
            <th>Action</th>
        </tr>
        <?php $__currentLoopData = $tanggungan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tgn): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><?php echo e(++$i); ?></td>
            <td><?php echo e($tgn->jumlah); ?></td>
            <td><?php echo e($tgn->nilai); ?></td>
            <td>
                <form action="<?php echo e(route('orangtua.destroy',$tgn->id )); ?>" method="POST">
                        
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('ortu-edit')): ?>
                        <a class="btn btn-warning" href="<?php echo e(URL::to('admin/ubahtanggungan/' . $tgn->id )); ?>"> Ubah </a>
                        
                    <?php endif; ?>


                    <?php echo csrf_field(); ?>
                    <?php echo method_field('DELETE'); ?>
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('ortu-delete')): ?>
                        <a data-id="<?php echo e($tgn->id); ?>" id="btndelete" class="btn btn-danger" href="#"> Hapus </a>
                        
                    <?php endif; ?>
                </form>
            </td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </table>

        
<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
    <link rel="stylesheet" href="/css/admin_custom.css">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    <script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>

    <script>
        $(function () {  
            $(document.body).on('click' , '#btndelete' , function (e) {
                e.preventDefault();
                let id = $(this).data("id");
                swal({
                    title: "Apakah anda yakin?",
                    text: "data yang dihapus tidak akan kembali!",
                    icon: "warning",
                    buttons: true,
                    dangerMode: true,
                    })
                    .then((willDelete) => {
                    if (willDelete) {
                        window.location.replace("http://127.0.0.1:8000/admin/hapustanggungan/" + id );
                    } 
                });
            });

        });
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\smartkid\resources\views/admin/tanggungan/index.blade.php ENDPATH**/ ?>