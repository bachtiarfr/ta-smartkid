

<?php $__env->startSection('title', 'Dashboard'); ?>

<?php $__env->startSection('content_header'); ?>
    <h1>Dashboard</h1>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <form action="<?php echo e(URL::to('admin/siswa')); ?>" method="post" enctype="multipart/form-data" >
    <?php echo csrf_field(); ?>

    <Label> Nomer Induk Siswa Nasional </Label>
    <input type="text" name="nisn" class="form-control">

    <Label> Nama Depan </Label>
    <input type="text" name="nama_depan" class="form-control">

    <Label> Nama Belakang </Label>
    <input type="text" name="nama_belakang" class="form-control">

    <label> Orang Tua / Wali </label>
    <select name="ortu_id" class="form-control">
        <?php $__currentLoopData = $ortu; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $or): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option value="<?php echo e($or->user_id); ?>"> <?php echo e($or->nama_depan); ?> </option>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </select>

    <label> Jenis Kelamin </label>
    <select name="jk" class="form-control">
        <option value="L"> Laki-Laki</option>
        <option value="P"> Perempuan </option>
    </select>

    <label> Jurusan </label>
    <select name="jurusan" class="form-control">
        <option value="Teknik Kendaraan Ringan"> Teknik Kendaraan Ringan </option>
        <option value="Teknik Permesinan"> Teknik Permesinan </option>
        <option value="Teknik Komputer Jaringan"> Teknik Komputer Jaringan </option>
        <option value="Teknik Kimia Industri"> Teknik Kimia Industri </option>
    </select>

    <label> Kelas </label>
    <select name="kelas" class="form-control">
        <option value="X"> Kelas X </option>
        <option value="XI"> Kelas XI </option>
        <option value="XII"> Kelas XII </option>
    </select>
    <hr>
    <div class="form-group mb-2">
        <Label> Prestasi </Label>
        <button id="btnplus" class="btn btn-success"> Tambah prestasi </button>
    </div>
    <div id="group_prestasi">
        <div class="col-md-9 form-inline p-0" id="dv_prestasi">
            <div class="form-group mb-3">
                <input type="text" name="prestasi" id="prestasi" class="form-control">
            </div>
        </div>
    </div>

    <hr>

    <label> Bukti Prestasi </label>
    <input type="file" name="berkas_prestasi" class="form-control mb-5">
    <input type="submit" value="simpan" name="simpan" class="btn btn-success">

    </form>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
    <link rel="stylesheet" href="/css/admin_custom.css">
    <style>
        .nav-link.dropdown-toggle::before {
            content: "Logout" !important;
        }
    </style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    <script>
        // membuat parameter
        let isi = '';
        let no = 1;

        $(function () {
            // kondisi jika diklik dengan jquery click
            $('#btnplus').click(function (e) { 
                e.preventDefault();
                // $('#dv_prestasi').clone().insertAfter('#dv_prestasi');

                // ambil form bagian input prestasi kemudia dicloning
                isi = `
                    <div class="col-md-9 form-inline p-0" id="dv_prestasi">
                        <div class="form-group mb-3">
                            <input type="text" name="prestasi${no}" id="prestasi${no}" class="form-control">
                            <div class="btn btn-danger ml-2 btnDelete">
                                <i class="fas fa-times"></i>
                            </div>
                        </div>
                    </div>
                `;

                no++;

                $('#group_prestasi').append( isi );
            });

            $(document).on("click", ".btnDelete", function(e) {
                e.preventDefault();
                $(this).parent().parent().remove();
            })

        });
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\smartkid\resources\views/admin/siswa/create.blade.php ENDPATH**/ ?>