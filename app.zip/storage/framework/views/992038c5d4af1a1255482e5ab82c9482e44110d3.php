

<?php $__env->startSection('title', 'Dashboard'); ?>

<?php $__env->startSection('content_header'); ?>
    <h1>Dashboard</h1>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <form action="<?php echo e(URL::to('admin/periode/' . $periode->id )); ?>" method="post">
        <?php echo csrf_field(); ?>
        <?php echo method_field("put"); ?>

        <label> Nama Beasiswa </label>
        <select name="beasiswa_id" class="form-control">
            <?php $__currentLoopData = $beasiswa; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $b): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option <?php echo e($periode->beasiswa_id == $b->id ? 'selected' : ''); ?> value="<?php echo e($b->id); ?>"> <?php echo e($b->nama_beasiswa); ?> </option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>

        <label> Semester </label>
        <select name="semester" class="form-control">
            <option <?php echo e($periode->semester == "Ganjil" ? "selected" : ""); ?> value="Ganjil"> Ganjil </option>
            <option <?php echo e($periode->semester == "Genap" ? "selected" : ""); ?> value="Genap"> Genap </option>
        </select>

        <label> Tahun Ajaran </label>
        <input type="text" name="tahun" class="form-control" value="<?php echo e($periode->tahun); ?>">

        <label> Status Beasiswa </label>
        <select name="status" class="form-control">
            <option <?php echo e($periode->status == "Aktif" ? "selected" : ""); ?> value="Aktif"> Aktif </option>
            <option <?php echo e($periode->status == "Non-Aktif" ? "selected" : ""); ?> value="Non-Aktif"> Non-Aktif </option>
        </select>

        <input type="submit" value="simpan" name="simpan" class="btn btn-success">

    </form>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
    <link rel="stylesheet" href="/css/admin_custom.css">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    <script> console.log('Hi!'); </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\smartkid\resources\views/admin/periode/edit.blade.php ENDPATH**/ ?>