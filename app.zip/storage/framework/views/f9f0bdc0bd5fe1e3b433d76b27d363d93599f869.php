

<?php $__env->startSection('title', 'Dashboard'); ?>

<?php $__env->startSection('content_header'); ?>
    <h1>Dashboard</h1>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <?php if($message = Session::get('success')): ?>
    <div class="alert alert-success">
        <p><?php echo e($message); ?></p>
    </div>
    <?php endif; ?>


    <table class="table table-striped table-hover table-bordered">
    <tr>
        <th> No </th>
        <th> Nama Siswa </th>
        <th> NISN </th>
        <th> Kelamin </th>
        <th> Kelas </th>
        <th> Jurusan </th>
        <th> Nama Orang Tua </th>
        <th> Penghasilan </th>
        <th> Beasiswa </th>
        <th> Semester </th>
        <th> Tahun </th>
        <th>Action</th>
    </tr>
    <?php $__currentLoopData = $pendaftar; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <tr>
        <td><?php echo e(++$i); ?></td>
        <td><?php echo e($p->name); ?></td>
        <td><?php echo e($p->nisn); ?></td>
        <td><?php echo e($p->jk); ?></td>
        <td><?php echo e($p->kelas); ?></td>
        <td><?php echo e($p->jurusan); ?></td>
        <td><?php echo e($p->name); ?></td>
        <td><?php echo e($p->penghasilan); ?></td>
        <td><?php echo e($p->nama_beasiswa); ?></td>
        <td><?php echo e($p->semester); ?></td>
        <td><?php echo e($p->tahun); ?></td>
        
        <td>
            <form action="<?php echo e(route('pendaftar.destroy',$p->id )); ?>" method="POST">
                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('ortu-edit')): ?>
                    <a class="btn btn-warning"href="<?php echo e(URL::to('admin/ubahpendaftar/' . $p->id )); ?>"> Ubah </a>
                    
                <?php endif; ?>


                <?php echo csrf_field(); ?>
                <?php echo method_field('DELETE'); ?>
                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('ortu-delete')): ?>
                    <a class="btn btn-danger" href="<?php echo e(URL::to('admin/hapuspendaftar/' . $p->id )); ?>"> Hapus </a>
                    
                <?php endif; ?>
            </form>
        </td>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tr>
    
    </table>


    <?php echo $pendaftar->links(); ?>

    <?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    <script> console.log('Hi!'); </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\smartkid\resources\views/admin/pendaftar/index.blade.php ENDPATH**/ ?>