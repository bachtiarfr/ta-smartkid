

<?php $__env->startSection('title', 'Dashboard'); ?>

<?php $__env->startSection('content_header'); ?>
    <h1>Dashboard</h1>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="col-md-8">
        <form action="<?php echo e(URL::to('admin/kondisi/' . $kondisi->id)); ?>" method="post" enctype="multipart/form-data" >
            <?php echo csrf_field(); ?>
            <?php echo method_field("put"); ?>

            <Label> Nama Orang Tua </Label>
            <select name="ortu_id" class="form-control">
                <?php $__currentLoopData = $ortu; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $or): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option <?php echo e($kondisi->ortu_id == $or->id ? "selected" : ""); ?> value="<?php echo e($or->id); ?>"> <?php echo e($or->name); ?> </option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
            
            <Label> Status Tempat Tinggal </Label>
            <select name="status_rumah" class="form-control">
                <option <?php echo e($kondisi->status_rumah == "pribadi" ? "selected" : ""); ?> value="pribadi"> Rumah Pribadi </option>
                <option <?php echo e($kondisi->status_rumah == "kontrak" ? "selected" : ""); ?> value="kontrak"> Rumah Kontrak </option>
                <option <?php echo e($kondisi->status_rumah == "milik orangtua" ? "selected" : ""); ?> value="milik orangtua"> Rumah Orang Tua </option>
            </select>

            <Label> Bangunan Rumah </Label>
            <select name="level_bangunan" class="form-control">
                <option <?php echo e($kondisi->level_bangunan == "permanen" ? "selected" : ""); ?> value="permanen"> Bangunan Permanen </option>
                <option <?php echo e($kondisi->level_bangunan == "non-permanen" ? "selected" : ""); ?> value="non-permanen"> Bangunan Tidak Permanen </option>
            </select>

            <Label> Berkas Pajak Bangunan </Label>
            <input type="file" name="berkas_surat_pajak" class="form-control">
            <img style="width:250px; height:150px;" src="<?php echo e(asset('images/' . $kondisi->berkas_surat_pajak)); ?>" >
            
            <br>

            <Label> Foto Rumah Tempat Tinggal </Label>
            <input type="file" name="photo" class="form-control" value="<?php echo e($kondisi->photo); ?>">
            <img style="width:250px; height:150px;" src="<?php echo e(asset('images/' . $kondisi->photo)); ?>" >

            <br> <br>

            <input type="submit" value="simpan" name="simpan" class="btn btn-success">
        </form>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
    <link rel="stylesheet" href="/css/admin_custom.css">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    <script> console.log('Hi!'); </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\smartkid\resources\views/admin/kondisi/edit.blade.php ENDPATH**/ ?>