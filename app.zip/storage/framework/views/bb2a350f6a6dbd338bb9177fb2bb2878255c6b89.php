

<?php $__env->startSection('title', 'Dashboard'); ?>

<?php $__env->startSection('content_header'); ?>
    <h1>Dashboard</h1>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <form action="<?php echo e(URL::to('admin/kondisi')); ?>" method="post" enctype="multipart/form-data" >
    <?php echo csrf_field(); ?>

    <label> Nama Orang Tua </label>
    <select name="ortu_id" class="form-control">
        <?php $__currentLoopData = $ortu; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $or): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option value="<?php echo e($or->id); ?>"> <?php echo e($or->name); ?> </option>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </select>

    <label> Status Tempat Tinggal </label>
    <select name="status_rumah" class="form-control">
        <option value="pribadi"> Rumah Pribadi </option>
        <option value="kontrak"> Rumah Kontrak / Sewa </option>
        <option value="milik orangtua"> Rumah Milik Orang Tua </option>
    </select>

    <label> Level Bangunan </label>
    <select name="level_bangunan" class="form-control">
        <option value="permanen"> Rumah Permanen </option>
        <option value="non-permanen"> Rumah Non-Permanen </option>
    </select>

    <label> Berkas Surat Pajak </label>
    <input type="file" name="berkas_surat_pajak" class="form-control">

    <label> Foto Rumah </label>
    <input type="file" name="photo" class="form-control">

    <input type="submit" value="simpan" name="simpan" class="btn btn-success">

    </form>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
    <link rel="stylesheet" href="/css/admin_custom.css">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    <script> console.log('Hi!'); </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\smartkid\resources\views/admin/kondisi/create.blade.php ENDPATH**/ ?>