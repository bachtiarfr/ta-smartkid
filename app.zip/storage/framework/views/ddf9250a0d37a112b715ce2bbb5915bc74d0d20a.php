

<?php $__env->startSection('title', 'Dashboard'); ?>

<?php $__env->startSection('content_header'); ?>
    <h1>Dashboard</h1>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <form action="<?php echo e(URL::to('admin/penghasilan/' . $penghasilan->id )); ?>" method="post">
        <?php echo csrf_field(); ?>
        <?php echo method_field("put"); ?>

        <label> Range Penghasilan Orang Tua </label>
        <input type="text" name="penghasilan" class="form-control" value="<?php echo e($penghasilan->penghasilan); ?>">

        <label> Bobot / Nilai </label>
        <input type="text" name="bobot" class="form-control" value="<?php echo e($penghasilan->bobot); ?>">

        <input type="submit" value="simpan" name="simpan" class="btn btn-success">

    </form>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
    <link rel="stylesheet" href="/css/admin_custom.css">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    <script> console.log('Hi!'); </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\smartkid\resources\views/admin/penghasilan/edit.blade.php ENDPATH**/ ?>