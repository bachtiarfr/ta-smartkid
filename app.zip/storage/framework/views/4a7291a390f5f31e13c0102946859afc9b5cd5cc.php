

<?php $__env->startSection('title', 'Dashboard'); ?>

<?php $__env->startSection('content_header'); ?>
    <h1>Dashboard</h1>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<script src = "http://cdn.datatables.net/1.10.18/js/jquery.dataTables.min.js" defer ></script>
<link rel="stylesheet" href="https://cdn.datatables.net/1.12.1/css/jquery.dataTables.min.css" crossorigin="anonymous" referrerpolicy="no-referrer" />

<link rel="stylesheet" href="/css/admin_custom.css">
    <style>
        .nav-link.dropdown-toggle::before {
            content: "Logout" !important;
        }
    </style>
<script src="<?php echo e(('js/main.js')); ?>"></script>
<script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>

<div class="row">
    <div class="col-md-12">
        <div class="card">
            <div class="card-header alert-success">
                Data Orang Tua 
            </div>
            <div class="card-body">
            <div class="row">
                <?php if($message = Session::get('success')): ?>
                <div class="alert alert-success">
                    <p><?php echo e($message); ?></p>
                </div>
                <?php endif; ?>
                <div class="col-md-12">
                    <table id="tblhasil" class="table table-bordered table-striped table-hover">
                        <thead>
                            <tr>
                                <td> No </td>
                                <td> NIK </td>
                                <td> NAMA LENGKAP </td>
                                <td> STATUS </td>
                                <td> PENDIDIKAN </td>
                                <td> PEKERJAAN </td>
                                <?php if(Auth::user()->role_id == 1): ?>
                                <th>Action</th>
                                <?php endif; ?>
                            </tr>
                        </thead>
                        <tbody id="v-content">
                          <?php
                              $i = 0;
                          ?>
                            <?php $__currentLoopData = $ortu; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ort): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e(++$i); ?></td>
                                <td><?php echo e($ort->nik); ?></td>
                                <td><?php echo e($ort->nama_depan . " " . $ort->nama_belakang); ?></td>
                                <td><?php echo e($ort->status); ?></td> 
                                <td><?php echo e($ort->pendidikan); ?></td>
                                <td><?php echo e($ort->pekerjaan); ?></td>
                                <?php if(Auth::user()->role_id == 1): ?>
                                <td>
                                    <form action="<?php echo e(route('orangtua.destroy',$ort->id )); ?>" method="POST">
                                        <a class="btn btn-warning" href="<?php echo e(URL::to('admin/ubahortu/' . $ort->id )); ?>"> Ubah </a>

                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('DELETE'); ?>
                                        <a data-id="<?php echo e($ort->id); ?>" id="btndelete" class="btn btn-danger" href="#"> Hapus </a>
                                    </form>
                                </td>
                                <?php endif; ?>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div> 
            </div>
        </div>
    </div>
</div>


<?php $__env->stopSection(); ?>
<?php $__env->startSection('css'); ?>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    <script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>

    <script>
        
        $(function () {
            $('table').DataTable();
            $(document.body).on('click' , '#btndelete' , function (e) {
                e.preventDefault();
                let id = $(this).data("id");
                swal({
                    title: "Apakah anda yakin?",
                    text: "data yang dihapus tidak akan kembali!",
                    icon: "warning",
                    buttons: true,
                    dangerMode: true,
                    })
                    .then((willDelete) => {
                    if (willDelete) {
                        window.location.replace("/admin/hapusortu/" + id );
                    }
                });
                
            });
        });
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\smartkid\resources\views/admin/ortu/index.blade.php ENDPATH**/ ?>